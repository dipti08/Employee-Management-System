﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class SalaryReport : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=project;Integrated Security=True");
        string com = "Select * from einfo";
        SqlDataAdapter adpt = new SqlDataAdapter(com, con);
        DataTable dt = new DataTable();
        adpt.Fill(dt);
        drpemp.DataSource = dt;
        drpemp.DataBind();
        drpemp.DataTextField = "empname";
        drpemp.DataValueField = "Id";
        drpemp.DataBind();
    }

    protected void btnselect_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=project;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from salaryreport where empname = '" + drpemp.SelectedValue + "'", con);
            SqlDataAdapter Adpt = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            DataColumn dtCol1 = new DataColumn();
            dt.Columns.Add(dtCol1);
            dt.Rows.Add(dt.NewRow());

            Adpt.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
            Label5.Text = "record found";
            drpmonth.SelectedIndex = 0;
            drpclass.SelectedIndex = 0;
            ((TextBox)txtyear).Text = "";
            drpclass.SelectedIndex = 0;
            Label5.ForeColor = System.Drawing.Color.Red;
            con.Close();
        }
        catch (Exception ex)
        {
            Label5.Text = ex.Message;
        }
    }
}