﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class ChangePassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button8_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=project;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("update alogin set pass=@pass where Id=1", con);
            cmd.Parameters.AddWithValue("@pass", txtnewpass.Text);

            SqlCommand cmd2 = new SqlCommand("update einfo set pass=@pass where Id=1", con);
            cmd2.Parameters.AddWithValue("@pass", txtnewpass.Text);

            con.Open();
            int i = cmd.ExecuteNonQuery();
            int j = cmd2.ExecuteNonQuery();
            con.Close();

            if (i != 0)
            {
                lbl.Text = "password changed successfully";
                lbl.ForeColor = System.Drawing.Color.Red;
                ((TextBox)txtid).Text = "";
                ((TextBox)txtcurrentpass).Text = "";
                ((TextBox)txtnewpass).Text = "";
                ((TextBox)txtconfmpass).Text = "";
                //lbl.Text = " ";
            }
            else
            {
                lbl.Text = "could not insert the data";
                lbl.ForeColor = System.Drawing.Color.Red;
                ((TextBox)txtid).Text = "";
                ((TextBox)txtcurrentpass).Text = "";
                ((TextBox)txtnewpass).Text = "";
                ((TextBox)txtconfmpass).Text = "";
            }
        }
        catch (Exception ex)
        {
            lbl.Text = ex.Message;
        }
    }
}