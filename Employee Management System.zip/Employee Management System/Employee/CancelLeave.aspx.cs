﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Employee_CancelLeave : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=project;Integrated Security=True");
        string com = "Select * from einfo";
        SqlDataAdapter adpt = new SqlDataAdapter(com, con);
        DataTable dt = new DataTable();
        adpt.Fill(dt);
        drpname.DataSource = dt;
        drpname.DataBind();
        drpname.DataTextField = "empname";
        drpname.DataValueField = "Id";
        drpname.DataBind();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=project;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from leave where empname = '" + drpname.SelectedValue + "'", con);
            SqlDataAdapter Adpt = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            DataColumn dtCol1 = new DataColumn();
            dt.Columns.Add(dtCol1);
            dt.Rows.Add(dt.NewRow());

            Adpt.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
            Label3.Text = "record found";
            Label3.ForeColor = System.Drawing.Color.Red;
            con.Close();
        }
        catch (Exception ex)
        {
            Label3.Text = ex.Message;
        }
    }
}