﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class ApplyLeave : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }



    protected void btnleave_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=project;Integrated Security=True");

            SqlCommand cmd = new SqlCommand("insert into leave(Id,empname,fromdate,todate,days,reason) values(@Id,@empname,@fromdate,@todate,@days,@reason) ", con);
            cmd.Parameters.AddWithValue("@Id", txtid.Text);
            cmd.Parameters.AddWithValue("@empname", txtname.Text);
            cmd.Parameters.AddWithValue("@fromdate", calfrom.SelectedDate);
            cmd.Parameters.AddWithValue("@todate", calto.SelectedDate);
            cmd.Parameters.AddWithValue("@days", drpdays.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@reason", txtreason.Text);
            con.Open();

            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (i != 0)
            {
                lbl.Text = "successfull addition";
                lbl.ForeColor = System.Drawing.Color.Red;
                ((TextBox)txtid).Text = "";
                ((TextBox)txtname).Text = "";
                calfrom.SelectedDates.Clear();
                calto.SelectedDates.Clear();
                drpdays.SelectedIndex = 0;
                ((TextBox)txtreason).Text = "";
                //lbl.Text = " ";
            }
            else
            {
                lbl.Text = "successfull addition";
                lbl.ForeColor = System.Drawing.Color.Red;
                ((TextBox)txtid).Text = "";
                ((TextBox)txtname).Text = "";
                calfrom.SelectedDates.Clear();
                calto.SelectedDates.Clear();
                drpdays.SelectedIndex = 0;
                ((TextBox)txtreason).Text = "";
                //lbl.Text = " ";
            }
       }
        catch (Exception ex)
        {
            lbl.Text = ex.Message;
        }

    }
}