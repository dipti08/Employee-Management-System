﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=project;Integrated Security=True");
        if (rdoadmin.Checked)
        {
            SqlCommand cmd = new SqlCommand("select * from alogin where empname=@empname and pass=@pass", con);
            cmd.Parameters.AddWithValue("@empname", txtuname.Text);
            cmd.Parameters.AddWithValue("@pass", txtpass.Text);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (dt.Rows.Count > 0)
            {
                Response.Redirect("Mainpage.aspx");
            }
            else
            {
                lbl.Text = "incorrect username or password";
                ((TextBox)txtuname).Text = "";
                lbl.ForeColor = System.Drawing.Color.Red;
            }
        }
        else if (rdoemployee.Checked)
        {
            SqlCommand cmd = new SqlCommand("select * from einfo where empname=@empname and pass=@pass", con);
            cmd.Parameters.AddWithValue("@empname", txtuname.Text);
            cmd.Parameters.AddWithValue("@pass", txtpass.Text);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (dt.Rows.Count > 0)
            {
                Response.Redirect("~/Employee/MyAccount.aspx");
            }
            else
            {
                lbl.Text = "incorrect username or password";
                ((TextBox)txtuname).Text = "";
                lbl.ForeColor = System.Drawing.Color.Red;
            }
        }


    }
}



