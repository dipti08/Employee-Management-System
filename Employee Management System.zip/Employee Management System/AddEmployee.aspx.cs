﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class AddEmployee : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnaddempl_Click1(object sender, EventArgs e)
    {

        try
        {
            SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=project;Integrated Security=True");
            SqlCommand cmd2 = new SqlCommand("insert into empshow(Id,name,designation,division,salary,bankaccount,mobile,email) values(@Id,@name,@designation,@division,@salary,@bankaccount,@mobile,@email) ", con);
            SqlCommand cmd = new SqlCommand("insert into einfo(Id,empname,pass,address,dob,caste,gender,qual,designation,division,location,class,emptype,category,payscale,salary,bankname,bankaccount,mobile,email,confirmpass) values(@Id,@empname,@pass,@address,@dob,@caste,@gender,@qual,@designation,@division,@location,@class,@emptype,@category,@payscale,@salary,@bankname,@bankaccount,@mobile,@email,@confirmpass) ", con);
            cmd.Parameters.AddWithValue("@Id", txtrefno.Text);
            cmd.Parameters.AddWithValue("@empname", txtname.Text);
            cmd.Parameters.AddWithValue("@pass", txtpassword.Text);
            cmd.Parameters.AddWithValue("@address", txtaddress.Text);
            cmd.Parameters.AddWithValue("@dob", txtdob.Text);
            cmd.Parameters.AddWithValue("@caste", drpcaste.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@gender", drpgender.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@qual", drpqual.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@designation", drpdesig.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@division", drpbranch.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@location", drplocation.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@class", drpclass.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@emptype", drpemptype.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@category", drpcat.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@payscale", drpscalepay.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@salary", txtsalary.Text);
            cmd.Parameters.AddWithValue("@bankname", drpbankname.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@bankaccount", txtbankaccountno.Text);
            cmd.Parameters.AddWithValue("@mobile", txtmobile.Text);
            cmd.Parameters.AddWithValue("@email", txtemail.Text);
            cmd.Parameters.AddWithValue("@confirmpass", txtconfpass.Text);

            cmd2.Parameters.AddWithValue("@Id", txtrefno.Text);
            cmd2.Parameters.AddWithValue("@name", txtname.Text);
            cmd2.Parameters.AddWithValue("@designation", drpdesig.SelectedItem.Value);
            cmd2.Parameters.AddWithValue("@division", drpbranch.SelectedItem.Value);
            cmd2.Parameters.AddWithValue("@salary", txtsalary.Text);
            cmd2.Parameters.AddWithValue("@bankaccount", txtbankaccountno.Text);
            cmd2.Parameters.AddWithValue("@mobile", txtmobile.Text);
            cmd2.Parameters.AddWithValue("@email", txtemail.Text);

            con.Open();
            int i = cmd.ExecuteNonQuery();
            int j = cmd2.ExecuteNonQuery();
            con.Close();

            if (i != 0)
            {
                lbl.Text = "successfull addition";
                lbl.ForeColor = System.Drawing.Color.Red;
                ((TextBox)txtrefno).Text = "";
                ((TextBox)txtname).Text = "";
                ((TextBox)txtaddress).Text = "";
                ((TextBox)txtdob).Text = "";
                drpcaste.SelectedIndex = 0;
                drpgender.SelectedIndex = 0;
                drpqual.SelectedIndex = 0;
                drpdesig.SelectedIndex = 0;
                drpbranch.SelectedIndex = 0;
                drplocation.SelectedIndex = 0;
                drpclass.SelectedIndex = 0;
                drpemptype.SelectedIndex = 0;
                drpcat.SelectedIndex = 0;
                drpscalepay.SelectedIndex = 0;
                ((TextBox)txtsalary).Text = "";
                drpbankname.SelectedIndex = 0;
                ((TextBox)txtbankaccountno).Text = "";
                ((TextBox)txtmobile).Text = "";
                ((TextBox)txtemail).Text = "";
                ((TextBox)txtpassword).Text = "";
                ((TextBox)txtconfpass).Text = "";
                //lbl.Text = " ";
            }
            else
            {
                lbl.Text = "could not insert the data";
                lbl.ForeColor = System.Drawing.Color.Red;
                ((TextBox)txtrefno).Text = "";
                ((TextBox)txtname).Text = "";
                ((TextBox)txtaddress).Text = "";
                ((TextBox)txtdob).Text = "";
                drpcaste.SelectedIndex = 0;
                drpgender.SelectedIndex = 0;
                drpqual.SelectedIndex = 0;
                drpdesig.SelectedIndex = 0;
                drpbranch.SelectedIndex = 0;
                drplocation.SelectedIndex = 0;
                drpclass.SelectedIndex = 0;
                drpemptype.SelectedIndex = 0;
                drpcat.SelectedIndex = 0;
                drpscalepay.SelectedIndex = 0;
                ((TextBox)txtsalary).Text = "";
                drpbankname.SelectedIndex = 0;
                ((TextBox)txtbankaccountno).Text = "";
                ((TextBox)txtmobile).Text = "";
                ((TextBox)txtemail).Text = "";
                ((TextBox)txtpassword).Text = "";
                ((TextBox)txtconfpass).Text = "";
            }
        }
        catch (Exception ex)
        {
            lbl.Text = ex.Message;
        }

    }

    



}



