﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data;
using System.Data.SqlClient;

public partial class EmployeeReport : System.Web.UI.Page
{
    

    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=project;Integrated Security=True");
        string com = "Select * from einfo";
        SqlDataAdapter adpt = new SqlDataAdapter(com, con);
        DataTable dt = new DataTable();
        adpt.Fill(dt);
        drpemployee0.DataSource = dt;
        drpemployee0.DataBind();
        drpemployee0.DataTextField = "empname";
        drpemployee0.DataValueField = "Id";
        drpemployee0.DataBind();
    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {





        /*
             SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=project;Integrated Security=True");
             con.Open();
             SqlCommand cmd = new SqlCommand("select * from einfo where empname= " + drpemployee0.SelectedItem.Value + "", con);
             SqlDataReader reader = cmd.ExecuteReader();

            while(reader.Read())
               {


                 object o1 = reader.GetValue(1);
                 lblname.Text=o1.ToString();
                 object o3 = reader.GetValue(3);
                 lbladd0.Text = o3.ToString();
                 object o4 = reader.GetValue(4);
                 lbldob0.Text = o4.ToString();
                 object o5 = reader.GetValue(5);
                 lblcaste0.Text = o5.ToString();
                 object o6 = reader.GetValue(6);
                 lblgender0.Text = o6.ToString();
                 object o7 = reader.GetValue(7);
                 lblqual0.Text = o7.ToString();
                 object o8 = reader.GetValue(8);
                 lbldesign1.Text = o8.ToString();
                 object o9 = reader.GetValue(9);
                 lbldivision0.Text = o9.ToString();
                 object o11 = reader.GetValue(11);
                 lblclass0.Text = o11.ToString();
                 object o12 = reader.GetValue(12);
                 lblemptype.Text = o12.ToString();
                 object o13 = reader.GetValue(13);
                 lblcategory.Text = o13.ToString();
                 object o14 = reader.GetValue(14);
                 lblpayscale0.Text = o14.ToString();
                 object o15 = reader.GetValue(15);
                 lblsalary0.Text = o15.ToString();
                 object o17 = reader.GetValue(17);
                 lblbankaco0.Text = o17.ToString();
                 object o18 = reader.GetValue(18);
                 lblmobile0.Text = o18.ToString();
                 object o19 = reader.GetValue(19);
                 lblemail0.Text = o19.ToString();


             }
             /*
             reader.Read();
                 lblname.Text = reader["empname"].ToString();

                 reader.Read();
                 lblpassword.Text = reader["pass"].ToString();

                 reader.Read();
                 lbladd0.Text = reader["address"].ToString();

                 reader.Read();
                 lbldob0.Text = reader["dob"].ToString();

                 reader.Read();
                 lblcaste0.Text = reader["caste"].ToString();

                 reader.Read();
                 lblgender0.Text = reader["gender"].ToString();

                 reader.Read();
                 lblqual0.Text = reader["qual"].ToString();

                 reader.Read();
                 lbldesign1.Text = reader["designation"].ToString();

                 reader.Read();
                 lbldivision0.Text = reader["division"].ToString();

                 reader.Read();
                 lblclass0.Text = reader["class"].ToString();

                 reader.Read();
                 lblpayscale0.Text = reader["payscale"].ToString();

                 reader.Read();
                 lblsalary0.Text = reader["salary"].ToString();

                 reader.Read();
                 lblbankaco0.Text = reader["bankaccount"].ToString();

                 reader.Read();
                 lblmobile0.Text = reader["mobile"].ToString();

                 reader.Read();
                 lblemail0.Text = reader["email"].ToString();


             reader.Close();
             con.Close();
        */
        try
        {
            SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=project;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from empshow where name = '" + drpemployee0.SelectedValue + "'", con);
            SqlDataAdapter Adpt = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            DataColumn dtCol1 = new DataColumn();
            dt.Columns.Add(dtCol1);
            dt.Rows.Add(dt.NewRow());
           
            Adpt.Fill(dt);
            GridView2.DataSource = dt;
            GridView2.DataBind();
            lbl.Text = "record found";
            lbl.ForeColor = System.Drawing.Color.Red;
            con.Close();
        }
        catch(Exception ex)
        {
            lbl.Text = ex.Message;
        }
        


    }
}